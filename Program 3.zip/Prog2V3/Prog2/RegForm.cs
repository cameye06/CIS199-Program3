﻿// Program 3
// CIS 199-02
// Due: 3/7/2017
// By:B8426

// This application calculates the earliest registration date
// and time for an undergraduate student given their class standing
// and last name.
// Decisions based on UofL Fall/Summer 2017 Priority Registration Schedule

// Program 3
// This solution keeps the first letter of the last name as a char
// and uses parallel arrays and sequential search for time logic and if/else for date
// It uses defined strings for the dates and 
// it uses arrays for the time 
// It only uses programming elements introduced in the text or
// in class.
// This solution takes advantage of the fact that there really are
// only two different time patterns used. One for juniors and seniors
// and one for sophomores and freshmen. The pattern for sophomores
// and freshmen is complicated by the fact the certain letter ranges
// get one date and other letter ranges get another date.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Find and display earliest registration time
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "March 29";  // 1st day of registration
            const string DAY2 = "March 30";  // 2nd day of registration
            const string DAY3 = "March 31";  // 3rd day of registration
            const string DAY4 = "April 3";   // 4th day of registration
            const string DAY5 = "April 4";   // 5th day of registration
            const string DAY6 = "April 5";   // 6th day of registration


            string[] timeSJArray = { "11:30 AM", "2:00 PM", "4:00 PM","8:30 AM","10:00 AM" };//holds the times for senior and junior
            char[] LastNameSJArray = { 'A','E', 'J','P','T'}; // low end of senior and junior initials
            string[] timeFSArray =  {"4:00 PM", "8:30 AM","10:00 AM", "11:30 AM",
                "2:00 PM", "4:00 PM", "8:30 AM","10:00 AM", "11:30 AM","2:00 PM"}; // holds the times for freshman and sophomore
            char[] LastNameFSArray = {'A','C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W'};// low end of freshman and sophomore initials

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            bool isUpperClass;        // Upperclass or not?

            lastNameStr = lastNameTxt.Text;
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                {
                    isUpperClass = (seniorRBtn.Checked || juniorRBtn.Checked);

                    // Juniors and Seniors share same schedule but different days
                     if (isUpperClass)
                     {
                         if (seniorRBtn.Checked)
                             dateStr = DAY1;
                         else // Must be juniors
                             dateStr = DAY2;
                /////////////////////////////////////////////////////////////////////////////////////////////performs a sequential search to find time
                       bool found = false; // switched to true when lastnNameLetterCh >= LastNameArray[index]
                       int index = LastNameSJArray.Length - 1; // Start from end
                       while (index >= 0 && !found) // iterates from end of array to beging, should stop when found=true
                       {
                           if (lastNameLetterCh >= LastNameSJArray[index])

                               found = true; // when it finds a letter in LastNameIN that is smaller than lastNAmeLetterCh
                           else
                               --index; // iteratesw backwards
                       }

                       if (found)
                       { timeStr = timeSJArray[index];} // sets timeStr to timeArray at same place that LastNameArray found a match
                   //////////////////////////////////////////////////////////////////////////////////////////

                    }




                    // Sophomores and Freshmen
                    else // Must be soph/fresh
                    {
                        if (sophomoreRBtn.Checked)
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY4;
                            else // All other letters on previous day
                                dateStr = DAY3;
                        }
                        else // must be freshman
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY6;
                            else // All other letters on previous day
                                dateStr = DAY5;
                        }

                        ///////////////////////////////////////////sequential search finds time
                        bool found = false; // switched to true when lastnNameLetterCh >= LastNameArray[index]
                        int index = LastNameFSArray.Length - 1; // Start from end
                        while (index >= 0 && !found) // iterates from end of array to beging, should stop when found=true
                        {
                            if (lastNameLetterCh >= LastNameFSArray[index])

                                found = true; // when it finds a letter in LastNameIN that is smaller than lastNAmeLetterCh
                            else
                                --index; // iteratesw backwards
                        }

                        if (found)
                        { timeStr = timeFSArray[index]; } // sets timeStr to timeArray at same place that LastNameArray found a match
                         ///////////////////////////////////////////////
                    }

                    // Output results
                    dateTimeLbl.Text = dateStr + " at " + timeStr;
                }
                else // First char not a letter
                    MessageBox.Show("Make sure last name starts with a letter");
            }
            else // Empty textbox
                MessageBox.Show("Enter a last name!");
        }
    }
}
